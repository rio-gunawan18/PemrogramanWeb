<?php

namespace Config;

class DatabaseConfig
{
    // SETTING KONFIGURASI DATABASE KALIAN
    public $host = "localhost";
    public $user = "root";
    public $password = "";
    public $database_name = "web_modul5";
    public $port = 3306;
}
