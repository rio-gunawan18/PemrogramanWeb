import React from "react";

const Hero = () => {
  return (
    <div className="hero">
      <h1>Yang ini hero yah gaes</h1>
    </div>
  );
};

export default Hero;
