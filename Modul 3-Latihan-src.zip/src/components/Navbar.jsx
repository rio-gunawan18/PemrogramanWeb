import React from "react";
import { Link } from "react-router-dom";

const Navbar = () => {
  return (
    <nav>
      <h2>Navbar</h2>
      <ul>
        <li>
          <button className="nav-button">
            <Link to="/">Home</Link>
          </button>
        </li>
        <li>
          <button className="nav-button">
            <Link to="/about">About</Link>
          </button>
        </li>
        <li>
          <button className="nav-button">
            <Link to="/contact">Contact</Link>
          </button>
        </li>
      </ul>
    </nav>
  );
};

export default Navbar;
