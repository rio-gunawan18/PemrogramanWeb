import React from "react";

const Contact = () => {
  return (
    <div>
      <h2>Ini Contact</h2>
    </div>
  );
};

export default Contact;
